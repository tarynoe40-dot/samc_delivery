local depositItem = "refined_uranium" 

exports.ox_target:addBoxZone({
    coords = vec3(4052.68, 2016.42, 23.53), -- CHANGE TO YOUR COORDS
    size = vec3(2, 2, 2),
    rotation = 0,
    debug = false, -- Debug is off, but the comma is still here
    options = {
        {
            name = 'samc_deposit_option',
            icon = 'fa-solid fa-box',
            label = 'Deposit Items',
            distance = 2.5,
            onSelect = function()
                local count = exports.ox_inventory:Search('count', depositItem)
                
                if count and count > 0 then
                    if lib.progressBar({
                        duration = 4800,
                        label = 'Depositing...',
                        useWhileDead = false,
                        canCancel = true,
                        anim = { dict = 'anim@heists@box_carry@', clip = 'idle' },
                    }) then
                        TriggerServerEvent('samc:server:completeDeposit', depositItem, count)
                    end
                else
                    lib.notify({
                        title = 'No Items',
                        description = 'You do not have any ' .. depositItem .. ' to deposit.',
                        type = 'error'
                    })
                end
            end
        }
    }
})