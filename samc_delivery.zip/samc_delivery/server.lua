RegisterNetEvent('samc:server:completeDeposit', function(itemName, amount)
    local src = source
    -- 1. Basic Safety Check
    if not src or src == 0 then return end 
    
    -- 2. Get the Player using Qbox export
    local player = exports.qbx_core:GetPlayer(src)
    
    -- 3. Critical Safety: Ensure player is fully loaded to prevent "no identifier" error
    if not player or not player.PlayerData or not player.PlayerData.citizenid then 
        print("^1[Error]^7 Attempted to access player " .. tostring(src) .. " before they were fully loaded.")
        return 
    end

    -- 4. Item Verification (Server-side check)
    local actualCount = exports.ox_inventory:GetItemCount(src, itemName)

    if actualCount >= amount and amount > 0 then
        -- 5. Remove the items
        if exports.ox_inventory:RemoveItem(src, itemName, amount) then
            
            -- 6. Give the money ($7500 per item)
            -- FIXED: Using Qbox export instead of old .Functions
            local totalPay = amount * 7500
            exports.qbx_core:AddMoney(src, 'bank', totalPay, "SAMC Deposit Reward")

            -- 7. Notify the player
            TriggerClientEvent('ox_lib:notify', src, {
                title = 'Payment Received',
                description = 'You earned $' .. totalPay .. ' for your delivery.',
                type = 'success'
            })
        end
    else
        -- Security logging
        print("^3[Warning]^7 Player " .. src .. " tried to deposit items they don't have: " .. tostring(itemName))
    end
end)