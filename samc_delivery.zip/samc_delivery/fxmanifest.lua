fx_version 'cerulean'
game 'gta5'

author 'lowkey'
description 'Simple SAMC Item Deposit System'
version '1.0.0'

-- Use Lua 5.4 for better performance with Qbox
lua54 'yes'

shared_scripts {
    '@ox_lib/init.lua', -- This is the magic line that makes lib.notify work
}

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependencies {
    'qbx_core',
    'ox_lib',
    'ox_inventory',
    'ox_target'
}